
function predict() {
  const input = document.getElementById('historyInput').value;
  const multipliers = input.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
  if (multipliers.length === 0) {
    document.getElementById('result').innerText = "Please enter valid numbers.";
    return;
  }

  const avg = multipliers.reduce((a, b) => a + b, 0) / multipliers.length;
  let trend = "";

  if (avg < 2) {
    trend = "Likely Low";
  } else if (avg < 10) {
    trend = "Likely Medium";
  } else {
    trend = "Possible High (10x+)";
  }

  document.getElementById('result').innerText = `Avg: ${avg.toFixed(2)} → ${trend}`;
}
